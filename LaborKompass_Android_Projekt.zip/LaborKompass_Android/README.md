# LaborKompass Pro – Android

Dies ist das native Android-Grundprojekt. Die App lädt LaborKompass aus dem eingebauten App-Speicher und behält Daten bei Updates, solange die App nicht deinstalliert und deren Daten nicht gelöscht werden.

## APK mit Android Studio erstellen
1. Android Studio installieren.
2. Diesen Ordner über **Open** öffnen.
3. Warten, bis Gradle synchronisiert ist.
4. **Build > Build APK(s)** wählen.
5. Die APK liegt danach unter `app/build/outputs/apk/debug/app-debug.apk`.

## APK ohne Android Studio über GitHub erstellen
1. Neuen privaten GitHub-Ordner anlegen.
2. Den gesamten Projektinhalt hochladen.
3. Register **Actions** öffnen.
4. Workflow **Android APK bauen** starten.
5. Das Artefakt **LaborKompass-Pro-APK** herunterladen.

## Installation auf Android
Die APK auf das Smartphone kopieren, antippen und die Installation aus dieser Quelle einmalig erlauben.

## Sicherungen
- Nach Änderungen legt die App intern lokale Versionen an.
- Unter Einstellungen kann ein JSON-Backup geteilt werden.
- Im Android-Teilen-Menü kann OneDrive ausgewählt werden.

Eine vollständig automatische OneDrive-Synchronisierung benötigt später eine Microsoft-App-Registrierung und Benutzeranmeldung.
