# LaborKompass Pro – derzeit keine besonderen Regeln erforderlich.
